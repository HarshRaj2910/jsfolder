import React from 'react'
import './Header.css'
function Header() {
  return (
    <div className='header'>
      <h1>Our Website</h1>
      <p>Our First Website</p>
    </div>
  )
}

export default Header
